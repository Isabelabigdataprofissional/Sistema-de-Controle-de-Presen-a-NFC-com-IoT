from paho.mqtt import client as clientMQTT
import json
from datetime import datetime, timedelta
import time
import random

broker = '195.35.43.33'
port = 1883
topics = ['aluno/id']
topic = 'aluno/id'
client_id = 'paho_mqtt'
username = "brware"
password = "SQRT(pi)!=314"
FIRST_RECONNECT_DELAY = 1
RECONNECT_RATE = 2
MAX_RECONNECT_COUNT = 12
MAX_RECONNECT_DELAY = 60
cafile='/etc/mosquitto/certs/fullchain1.pem'
cert_file='/etc/mosquitto/certs/cert1.pem'
key_file='/etc/mosquitto/certs/privkey1.pem'

'''def on_disconnect(client, userdata, rc):
    logging.info("Disconnected with result code: %s", rc)
    reconnect_count, reconnect_dely = 0, FIRST_RECONNECT_DELAY
    while reconnect_count < MAX_RECONNECT_COUNT
          logging.info("Reconnecting in %d seconds...", reconnect_delay)
          time.sleep(reconnect_delay)

          try:
              client.reconnect()
              logging.info("Reconnected sucessfully!")
              return
          except Exception as err:
              logging.error("%s. Reconnect failed. Retrying...", err)

          reconnect_delay *= RECONNECT_RATE
          reconnect_delay = min(reconnect_delay, MAX_RECONNECT_DELAY)
          reconnect_count += 1
    logging.info("Reconnect failed after %s attempts. Exiting...", reconnect_count)'''

def connect_mqtt():
    def on_connect(client, userdata, flags, rc , properties):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)
    client = clientMQTT.Client(client_id=client_id, callback_api_version=clientMQTT.CallbackAPIVersion.VERSION2)

    client.on_connect = on_connect
    client.username_pw_set(username, password)

    client.connect(broker, port, keepalive=120)
    #client.on_disconnect = on_disconnect
    return client

def publish(client: clientMQTT, dados):
        time.sleep(1)
        msg = {}
        msg["Quant. malotes"] = dados
        msg_json = json.dumps(msg)
        result = client.publish(topic, msg_json)
        status = result[0]
        if status == 0:
            print(F"Send `{msg}` to topic `{topic}`")
        else:
            print(f"Failed to send message to topic {topic}")

def subscribe(client: clientMQTT):
    def on_message(client, userdata, msg):
        print(f"Received `{msg.payload.decode()}` from `{msg.topic}` topic")
        payload_str = msg.payload.decode("utf-8")
        dados = json.loads(payload_str)
        try:
            if msg.topic == "aluno/id":
               print(f"Mensagem armazenada: {msg.topic}")
            else:
               print(f"Mensagem armazenada: {msg.topic}")
                
        except Exception as e:
            print(f"Erro: {e}")

    client.subscribe(topic)
    #client.subscribe(topics[2])
    client.on_message = on_message

def run():
    #qnt_malote = int(input("Informe a quantidade de malotes no carrinho: "))
    client = connect_mqtt()
    #client.loop_start()
    #publish(client, qnt_malote)
    #client.loop_stop()
    subscribe(client)
    client.loop_forever()

if __name__ == '__main__':
    run()
